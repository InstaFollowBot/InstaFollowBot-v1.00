from instapy import InstaPy

session = InstaPy(username="yourusername", password="yourpassword")
session.login()
#login section

#like section
session.like_by_tags(['entertag', 'entertag'], amount=6000)


#follow section
session.set_do_follow(True, percentage=50)


#comment section 
session.set_do_comment(True, percentage=50)
session.set_comments(['entercomment',])

session.end()